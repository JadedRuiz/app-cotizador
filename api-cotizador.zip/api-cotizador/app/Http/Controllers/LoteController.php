<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Utils\Errores;
use App\Models\Lote;
use App\Models\Etapa;

class LoteController extends Controller
{
    //Metodos Genericos
    public function obtenerLotesEtapa($iIdEtapa) {
        try{
            $lote= Lote::select('iIdLote','iLote','sTipoLote','iSuperficie','bIrregular','iAncho','iLargo', 'iStatus', 'iPrecioM2Contado')
            ->where('iIdEtapa',$iIdEtapa)
            ->where('bActivo',1)
            ->get();


            return $this->crearRespuesta(1,$lote,200);
        }catch(\Exception $e) {
            return $this->crearRespuesta(2,Errores::getError("G001",$e->getMessage()),201);
        }
    }
}
