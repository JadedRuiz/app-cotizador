<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Etapa;
use App\Models\Plazo;

class EtapaController extends Controller
{
    public function getEtapas($iIdProyecto) {
        $etapa = Etapa::where('iIdProyecto',$iIdProyecto)
        ->where('bActivo',1)
        ->orderBy('iOrden','ASC')
        ->get();
        return $this->crearRespuesta(1,$etapa,200);
    }

    public function obtenerPlazosPorEtapa($iIdEtapa) {
        $plazos = Plazo::select('iIdPlazo', 'sPlazo', 'iNoPlazo', 'iInteres')
        ->where('iIdEtapa',$iIdEtapa)
        ->where('bActivo',1)
        ->get();
        return $this->crearRespuesta(1,$plazos,200);
    }

    //Admin

    public function getEtapasAdmin(Request $request) {
        $usuario = json_decode($this->decode_json($request["token"]));

        return Etapa::where("iIdEmpresa",$usuario->iIdEmpresa)->get();
        return json_encode();
    }
}
